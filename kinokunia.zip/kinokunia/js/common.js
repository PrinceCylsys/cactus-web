
$(document).ready(function(){
	
	/* holiday message across site */
    //$( "#contact_details_wrap span.red" ).remove();
    $( "#contact_details_wrap span.red" ).html( "<p style=color:#ff991f;line-height:16px>英文校正は日曜12:30～21:30も営業(※電話対応不可)</p>");
    //$( "#contact_details_wrap span.red" ).text( "4月29日（昭和の日）も通常営業");
    /* add pop over classes and elements*/
    //$( "#contact_details_wrap span.red" ).css('background-color', '#f96d03').css('visibility','visible').css('display','block').css('padding','0px 0px');
//    $("head").append("<style> .hover-holiday{ position:relative; } </style>");
//    $("#contact_details_wrap span.red").addClass('hover-holiday');
   
    /*change work timings*/
        //if($('#contact_details_wrap')){
//            $("#contact_details_wrap span").each(function(){
//                if($(this).text().length > 0 && $(this).text().trim() == '平日・祝日 9:30～24:00 土 12:30～21:30') {
//                   $(this).text('平日・祝日 9:30～24:00 土 12:30～21:30');
//                }
//            });
//        }
//console.log($('#contact_details_wrap').text());
/*change work timings ends*/
    
   // $("#contact_details_wrap span.red").append("<div class='tooltip-holiday'>12月23日(天皇誕生日)・年末年始・1月8日（成人の日）も通常営業。元旦のみ12:30~21:30の営業となります。 <div class='arrowShadow-holiday'></div></div>");

    //$("head").append("<style> .tooltip-holiday{text-align: left;top: -63px;right: -1px;background-color: #bf0113;color: white;border-radius: 5px;opacity: 0;width: 275px;position: absolute;-webkit-transition: opacity 0.5s;-moz-transition: opacity 0.5s;-ms-transition: opacity 0.5s;-o-transition: opacity 0.5s;transition: opacity 0.5s; z-index: 2;padding: 10px;border: 2px solid #e16a00;background: #fcf0e5;color: black;font-family: 'MS Gothic';height: 30px;visibility: hidden;} .arrowShadow-holiday {width: 0px;height: 0px;border-left: 10px solid transparent;border-right: 10px solid transparent;border-top: 10px solid #e16a00;font-size: 0px;line-height: 0px;position: relative;top: 9px;left: 145px;z-index: 200;} </style>");
    
    //$("head").append("<style> .hover-holiday:hover .tooltip-holiday {opacity:1;} </style>");
    
   // $( "#contact_details_wrap span.red" ).hover(function(){
   //     $('.tooltip-holiday').css('visibility', 'visible');
    //});
   // $("#contact_details_wrap span.red" ).mouseleave(function(){
  //      $('.tooltip-holiday').css('visibility', 'hidden');
    //});
	/* add pop over classes and elements ends*/
    
	$(".btn-slide").click(function(){
		$("#panel").slideToggle("slow");
		$(this).toggleClass("active"); return false;
	});
	
	/* noti-wrapper bottom popup starts */
	 /* setTimeout(function(){
           $( ".noti-wrapper" ).animate({opacity: '1'});
     },2500); // 5000 milliseconds means 5 seconds.

	 $(".noti-close").click(function(){
        $(".noti-wrapper").fadeOut(1000);
		$(".noti-maximize").hide();
	 });
	
	$(".noti-minimize").click(function(){
        $(".noti-wrapper").animate({left: '100%', opacity: '0'});
		$(".noti-maximize").animate({right: '0', opacity: '1'});
	});
	
	$(".noti-maximize").click(function(){
        $(".noti-wrapper").animate({left: '0px', opacity: '1'});
		$(".noti-minimize").animate({left: '0px', opacity: '1'});
		$(".noti-maximize").animate({right: '-100%', opacity: '1'});
	});	  


});

$(window).bind("load", function() {
   $('.noti-wrapper').fadeIn(50000);
});
*/
	/* noti-wrapper bottom popup ends */

$(document).ready(function() {
    $('.subjectlist_table').dataTable({
        "paging": true,
        "ordering": false,
        "info": false,
        "tfoot": false,
        "lengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ]
    });

});
});
$("#contact_details_wrap span.red").hover(function(){
    $('#holiday-msg-hover').show();
}, function(){
    $('#holiday-msg-hover').hide();
});

/*Home page slider starts*/
$('#ed_kino_slider').slick({
    dots: true,
    arrows: false,
    adaptiveHeight:true,
    autoplay: true,
    autoplaySpeed: 3000
});
/*Home page slider ends*/